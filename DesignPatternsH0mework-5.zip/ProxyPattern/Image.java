public interface Image {
    void showSmall();
    void showFull();
}